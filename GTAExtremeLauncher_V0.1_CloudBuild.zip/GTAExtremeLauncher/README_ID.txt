GTA SA EXTREME INDONESIA LAUNCHER - TEST BUILD V0.1

Isi:
- Project Android native (Kotlin + WebView lokal)
- Tampilan launcher portrait
- Tombol Play (simulasi), Graphics, Controls, About, Game Files
- Tidak menyertakan game GTA SA atau aset/mod pihak ketiga

PENTING:
Ini adalah project source Android, belum APK siap instal. Lingkungan pembuatan ini tidak memiliki Android SDK/build-tools, jadi APK belum dapat dikompilasi di sini.

Cara build:
1. Buka folder project ini di Android Studio atau AndroidIDE yang kompatibel dengan Android Gradle Plugin 8.7.3.
2. Gunakan JDK 17 atau 21 dan Android SDK Platform 35.
3. Tunggu Gradle sync selesai.
4. Jalankan task :app:assembleDebug.
5. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Package: id.gtaextreme.launcher
Min Android: 6.0 (API 23)
Version: 0.1-test

BUILD APK TANPA PC (MELALUI GITHUB ACTIONS):
1. Buat akun GitHub jika belum punya, lalu buat repository baru (Public atau Private).
2. Upload seluruh ISI folder project ini ke repository tersebut, termasuk folder .github.
3. Buka tab Actions pada repository dan pilih workflow "Build Android APK".
4. Tekan "Run workflow" jika belum berjalan otomatis.
5. Setelah selesai (status hijau), buka hasil run dan unduh artifact "GTA-Extreme-Launcher-V0.1-debug".
6. Ekstrak ZIP artifact di HP, lalu instal app-debug.apk. Jika diminta, izinkan instalasi dari sumber tersebut.

Catatan: Build cloud memerlukan koneksi internet dan akun GitHub. APK ini hanya launcher uji; tombol Play belum menjalankan GTA SA.
